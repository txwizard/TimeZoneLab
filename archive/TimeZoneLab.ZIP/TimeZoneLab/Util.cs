﻿/*
    ============================================================================

    Namespace:          TimeZoneLab

    Class Name:         Util

    File Name:          Util.cs

    Synopsis:           This sealed class exposes static utility routines used
                        by the working classes in this assembly.

    ToDo:               Several recent assemblies contains like named classes.
                        They should be organized into a single class, and put
                        into a library.

    Author:             David A. Gray, Simple Soft Services, Inc.

    Copyright:          Copyright 2014, Simple Soft Services, Inc.

    Created:            Monday, 01 September 2014 and Tuesday, 01 September 2014

    ----------------------------------------------------------------------------
    Revision History
    ----------------------------------------------------------------------------

    Date       Version Author Description
    ---------- ------- ------ --------------------------------------------------
    2014/09/02 1.0     DAG/WW Initial implementation.
    2014/09/04 1.1     DAG/WW Clean up documentation and formatting of output to
                              make the project suitable for publication.
    ============================================================================
*/


using System;
using System.Collections.Generic;
using System.Reflection;
using System.Text;
using WizardWrx.ApplicationHelpers2;
using System.IO;


namespace TimeZoneLab
{
    public sealed class Util
    {
        #region Frequently Used Constants
        /// <summary>
        /// Always start writing whole blocks at the beginning of the allocated
        /// buffer, which is precisely sized to hold one block.
        /// </summary>
        public const int BEGINNING_OF_BUFFER = 0;


        /// <summary>
        /// Many methods process labeled delimited text files, and frequently
        /// need to exclude the label row from consideration, for example, when
        /// setting the initial capacity of a collection.
        /// </summary>
        public const int EXCLUDE_LABEL_ROW = +1;


        /// <summary>
        /// There are several methods that need to know if they are dealing with
        /// the first record of the whole file or of a block.
        /// </summary>
        public const long FIRST_RECORD = +1;


        /// <summary>
        /// Use this format string, followed by an optional precision 
        /// specification digit, to format a number as a percentage.
        /// 
        /// Be aware that the formatter handles the decimal place shift.
        /// </summary>
        public const string NUMERIC_FORMAT_PERCENTAGE = "P";


        /// <summary>
        /// Use this format string to format an integer without any digits
        /// following the (absent) decimal point.
        /// </summary>
        public const string NUMERIC_FORMAT_INTEGER_NO_DECIMAL = "N0";


        /// <summary>
        /// Arrays subscripting starts at zero. End of discussion.
        /// </summary>
        public const int ARRAY_FIRST_ELEMENT = 0;


        /// <summary>
        /// Since array subscripting starts at zero, it follows that minus one
        /// is an invalud subscript, which has all sorts of uses, such as
        /// initializing a subscript so that you can tell when it is used for
        /// the first time.
        /// </summary>
        public const int ARRAY_INVALID_INDEX = -1;


        /// <summary>
        /// There are many opportunities when plus one really means "the next
        /// element in the array." Use this constant to document such cases.
        /// </summary>
        public const int ARRAY_NEXT_ELEMENT = +1;


        /// <summary>
        /// Derive the ordinal of an element by adding this constant to its
        /// subscript. Likewise, subtract it from an ordinal to derive the
        /// corresponding subscript.
        /// </summary>
        public const int ARRAY_SUBSCRIPT_TO_ORDINAL = +1;


        /// <summary>
        /// Substitute for zero when zero menas that something, such as a
        /// collection, file, or list, is empty.
        /// </summary>
        public const int EMPTY = WizardWrx.StandardConstants.ZERO;


        /// <summary>
        /// Substitute for zero when it represents the first element of an array.
        /// </summary>
        public const int FIRST_ITEM = WizardWrx.StandardConstants.ARRAY_FIRST_ELEMENT;


        /// <summary>
        /// Use this to allocate a StringBuilder for assembling a long line,
        /// such as the fields of a wide report.
        /// </summary>
        public const int LINE_BUFFER_SIZE = WizardWrx.StandardConstants.SB_CAPACITY_01KB;


        /// <summary>
        /// Use this when plus one is the next index (subscript) of an array.
        /// </summary>
        public const int NEXT_INDEX = WizardWrx.StandardConstants.PLUS_ONE;


        /// <summary>
        /// Add this to a subscript to derive the corresponding ordinal.
        /// 
        /// Likewise, you may sutract it from an ordinal to derive the
        /// corresponding subscript.
        /// </summary>
        public const int ORDINAL_FROM_INDEX = WizardWrx.StandardConstants.ARRAY_LIST_ORDINAL_TO_SUBSCRIPT;


        /// <summary>
        /// Use this when your code calls for a single space when you want the
        /// listing to be crystal clear about what it is.
        /// </summary>
        public const char SPACE_CHAR = WizardWrx.StandardConstants.SINGLE_SPACE;


        /// <summary>
        /// I use this with my SysDateFormatters class to format a date and time
        /// so that it prints as yyyy/mm/dd hh:mm:ss.
        /// </summary>
        /// <example>2014/09/04 16:17:30</example>
        public const string STANDARD_DISPLAY_TIME_FORMAT = SysDateFormatters.RFD_YYYY_MM_DD_HH_MM_SS;


        /// <summary>
        /// This is for reference; the recommended way to get the 
        /// </summary>
        public const string UTC_TIMEZONE_ID = @"UTC";
        #endregion  // #region Frequently Used Constants


        #region Public Static Methods
        /// <summary>
        /// Use my standard format string for displaying dates in reports to
        /// format a DateTime structure.
        /// </summary>
        /// <param name="pdtmTestDate">
        /// Specify the populated DateTime to be formatted.
        /// </param>
        /// <returns>
        /// The return value is a string representation of the date, redered
        /// according to string constant STANDARD_DISPLAY_TIME_FORMAT.
        /// </returns>
        public static string FormatDateForShow ( DateTime pdtmTestDate )
        {
            return SysDateFormatters.ReformatSysDate (
                pdtmTestDate ,
                STANDARD_DISPLAY_TIME_FORMAT );
        }   // public static string FormatDateForShow


        /// <summary>
        /// Given a DateTime and a system time zone ID string, return the
        /// appropriate text to display, depending on whether the specified time
        /// is standard or Daylight Saving Time.
        /// </summary>
        /// <param name="pdtmTestDate">
        /// Specify the Syatem.DateTime for which the appropriate time zone
        /// string is required.
        /// </param>
        /// <param name="pstrTimeZoneID">
        /// Specify a valid time zone ID string. Please see the Remarks.
        /// </param>
        /// <returns>
        /// If the function succeeds, the return value is the appropriate string
        /// to display for the given time. Otherwise, the empty string is
        /// returned or one of several exceptions is thrown, the most likely of
        /// which is a TimeZoneNotFoundException, which is thrown when the
        /// specified time zone ID string is invalid.
        /// </returns>
        /// <exception cref="OutOfMemoryException">
        /// You should restart Windows if this happens.
        /// </exception>
        /// <exception cref="ArgumentNullException">
        /// Contact the author of the program. This is something that he or she
        /// must address.
        /// </exception>
        /// <exception cref="TimeZoneNotFoundException">
        /// Contact the author of the program. This is something that he or she
        /// must address.
        /// </exception>
        /// <exception cref="System.Security.SecurityException">
        /// Contact your system administrator to inquire about why your program
        /// is forbidden to read the regional settings from the Windows
        /// Registry.
        /// </exception>
        /// <exception cref="InvalidTimeZoneException">
        /// Contact your system support group. A corrupted Windows Registry is a
        /// rare, but serious matter.
        /// </exception>
        /// <exception cref="Exception">
        /// Start with your system support group, who may need to request the
        /// assistance of the author of the program.
        /// </exception>
        /// <remarks>
        /// if in doubt, use TimeZoneInfo.GetSystemTimeZones to enumerate the
        /// time zones installed on the local machine.
        /// </remarks>
        public static string GetDisplayTimeZone (
            DateTime pdtmTestDate ,
            string pstrTimeZoneID )
        {
            const string ERRMSG_NO_MEMORY = "SYSTEM RESOURCE FAMINE: The GetDisplayTimeZone method ran out of memory.";
            const string ERRMSG_NULL_TZ_ID = "INTERNAL ERROR: The GetDisplayTimeZone method let a null pstrTimeZoneID through to TimeZoneInfo.FindSystemTimeZoneById.";
            const string ERRMSG_TZ_NOT_FOUND = "INTERNAL or DATA ERROR: The GetDisplayTimeZone method let a pstrTimeZoneID that isn't registered on this computer through to TimeZoneInfo.FindSystemTimeZoneById.{1}                        Specified ID = {0}";
            const string ERRMSG_SECURITY = "ACCESS VIOLATION: The GetDisplayTimeZone method cannot read the Registry keys where the time zone information is kept. The process has insufficient access permissions on that key.";
            const string ERRMSG_INV_TZINFO = "CORRUPTED SYSTEM REGISTRY: The GetDisplayTimeZone method found the specified key, but the corresponding Registry key is corrupted.{1}                           Specified ID = {0}";
            const string ERRMSG_RUNTIME = "RUNTIME EXCEPTION: The GetDisplayTimeZone method found the specified key, but the corresponding Registry key is corrupted.{1}                    Specified ID = {0}";

            if ( pdtmTestDate == DateTime.MinValue || pdtmTestDate == DateTime.MaxValue || string.IsNullOrEmpty ( pstrTimeZoneID ) )
            {   // Insufficient data available
                return string.Empty;
            }   // TRUE (degenerate case) block, if ( pdtmTestDate == DateTime.MinValue || pdtmTestDate == DateTime.MaxValue || string.IsNullOrEmpty(pstrTimeZoneID) )
            else
            {
                try
                {
                    TimeZoneInfo tzinfo = TimeZoneInfo.FindSystemTimeZoneById ( pstrTimeZoneID );
                    return tzinfo.IsDaylightSavingTime ( pdtmTestDate ) ?
                        tzinfo.DaylightName :
                        tzinfo.StandardName;
                }
                catch ( OutOfMemoryException exNoMem )
                {
                    throw new Exception (
                        ERRMSG_NO_MEMORY ,
                        exNoMem );
                }
                catch ( ArgumentNullException exNullID )
                {
                    throw new Exception (
                        ERRMSG_NULL_TZ_ID ,
                        exNullID );
                }
                catch ( TimeZoneNotFoundException exTZNotFound )
                {
                    throw new Exception (
                        string.Format (
                            ERRMSG_TZ_NOT_FOUND ,
                            pstrTimeZoneID ,
                            Environment.NewLine ) ,
                        exTZNotFound );
                }
                catch ( System.Security.SecurityException exSecurity )
                {
                    throw new Exception (
                        ERRMSG_SECURITY ,
                        exSecurity );
                }
                catch ( InvalidTimeZoneException exInvTZInfo )
                {
                    throw new Exception (
                        string.Format (
                            ERRMSG_INV_TZINFO ,
                            pstrTimeZoneID ,
                            Environment.NewLine ) ,
                        exInvTZInfo );
                }
                catch ( Exception exMisc )
                {
                    throw new Exception (
                        string.Format (
                            ERRMSG_RUNTIME ,
                            pstrTimeZoneID ,
                            Environment.NewLine ) ,
                        exMisc );
                }
            }   // FALSE (desired outcome) block, if ( pdtmTestDate == DateTime.MinValue || pdtmTestDate == DateTime.MaxValue || string.IsNullOrEmpty(pstrTimeZoneID) )
        }   // public static string GetDisplayTimeZone


        /// <summary>
        /// Return TRUE if the FOR loop driven by pintLoopIndex is on its last
        /// iteration, given that the limit criterion is pintLoopIndex is less
        /// than or equal to pintLimit.
        /// </summary>
        /// <param name="pintLoopIndex">
        /// Specify the integer loop index.
        /// </param>
        /// <param name="pintLimit">
        /// Specify the integer limit value.
        /// </param>
        /// <returns>
        /// This function returns TRUE if the next increment of the loop index
        /// would set it equal to pintLimit, stopping the loop without another
        /// iteration.
        /// </returns>
        /// <seealso cref="MoreForIterationsToComeLE"/>
        public static bool IsLastForIterationLE (
            int pintLoopIndex ,
            int pintLimit )
        {
            return pintLoopIndex + NEXT_INDEX == pintLimit;
        }   // public static bool IsLastForIterationLE
        /// <summary>
        /// Load the lines of a plain ASCII text file that has been stored with
        /// the assembly as a embedded resource into an array of native strings.
        /// </summary>
        /// <param name="pstrResourceName">
        /// Specify the fully qualified resource name, which is its source file
        /// name appended to the default application namespace.
        /// </param>
        /// <returns>
        /// The return value is an array of Unicode strings, each of which is
        /// the text of a line from the original text file, sans terminator.
        /// </returns>
        /// <see cref="LoadTextFileFromAnyAssembly"/>
        /// <seealso cref="LoadTextFileFromCallingAssembly"/>
        public static string [ ] LoadTextFileFromEntryAssembly (
            string pstrResourceName )
        {
            return LoadTextFileFromAnyAssembly (
                pstrResourceName ,
                Assembly.GetEntryAssembly ( ) );
        }   // public static string [ ] LoadTextFileFromEntryAssembly
        /// <summary>
        /// <param name="pstrResourceName">
        /// Specify the fully qualified resource name, which is its source file
        /// name appended to the default application namespace.
        /// </param>
        /// </summary>
        /// <param name="pstrResourceName">
        /// Specify the fully qualified resource name, which is its source file
        /// name appended to the default application namespace.
        /// </param>
        /// <param name="pasmSource">
        /// Pass in a reference to the Assembly from which you expect to load
        /// the text file. Use any means at your disposal to obtain a reference
        /// from the System.Reflection namespace.
        /// </param>
        /// <returns></returns>
        /// <seealso cref="LoadTextFileFromCallingAssembly"/>
        /// <seealso cref="LoadTextFileFromEntryAssembly"/>
        private static string [ ] LoadTextFileFromAnyAssembly (
            string pstrResourceName ,
            Assembly pasmSource )
        {
            string strInternalName = GetInternalResourceName (
                pstrResourceName ,
                pasmSource );

            if ( strInternalName == null )
                throw new Exception (
                    string.Format (
                        Properties.Resources.ERRMSG_EMBEDDED_RESOURCE_NOT_FOUND ,
                        pstrResourceName ,
                        pasmSource.FullName ) );

            Stream stroTheFile = pasmSource.GetManifestResourceStream ( strInternalName );

            //  ----------------------------------------------------------------
            //  The character count is used several times, always as an integer.
            //  Cast it once, and keep it, since implicit casts create new local
            //  variables.
            //
            //  The integer is immediately put to use, to allocate a byte array,
            //  which must have room for every character in the input file.
            //  ----------------------------------------------------------------

            int intTotalBytesAsInt = ( int ) stroTheFile.Length;
            byte [ ] abytWholeFile = new Byte [ intTotalBytesAsInt ];
            int intBytesRead = stroTheFile.Read (
                abytWholeFile ,                         // Buffer sufficient to hold it.
                BEGINNING_OF_BUFFER ,                   // Read from the beginning of the file.
                intTotalBytesAsInt );                   // Swallow the file whole.

            //  ----------------------------------------------------------------
            //  Though its backing store is a resource embedded in the assembly,
            //  it must be treated like any other stream. Investigating in the
            //  Visual Studio Debugger showed me that it is implemented as an
            //  UnmanagedMemoryStream. That "unmanaged" prefix is a clarion call
            //  that the stream must be cloaed, disposed, and destoryed.
            //  ----------------------------------------------------------------

            stroTheFile.Close ( );
            stroTheFile.Dispose ( );
            stroTheFile = null;

            //  ----------------------------------------------------------------
            //  In the unlikely event that the byte count is short (or long),
            //  the program must croak. Since the three items that we want to
            //  include in the report are stored in local variables, including
            //  the reported file length, we can go ahead and close the stream
            //  before the count of bytes read is evaluated. HOWEVER, you must
            //  USE them, or you get a null reference exception that masks the
            //  real error.
            //  ----------------------------------------------------------------

            if ( intBytesRead != intTotalBytesAsInt )
                throw new InvalidDataException (
                    string.Format (
                        Properties.Resources.ERRMSG_EMBEDDED_RESOURCE_READ_ERROR ,
                        new object [ ]
                        {
                            strInternalName ,
                            intTotalBytesAsInt ,
                            intBytesRead ,
                            Environment.NewLine
                        } ) );

            //  ----------------------------------------------------------------
            //  The file is stored in single-byte ASCII characters. The native 
            //  character set of the Common Language Runtime is Unicode. A new
            //  array of Unicode characters serves as a translation buffer which
            //  is filled a character at a time from the byte array.
            //  ----------------------------------------------------------------

            char [ ] achrWholeFile = new char [ intTotalBytesAsInt ];

            for ( int intCurrentByte = BEGINNING_OF_BUFFER ;
                      intCurrentByte < intTotalBytesAsInt ;
                      intCurrentByte++ )
                achrWholeFile [ intCurrentByte ] = ( char ) abytWholeFile [ intCurrentByte ];

            //  ----------------------------------------------------------------
            //  The character array converts to a Unicode string in one fell
            //  swoop. Since the new string vanishes when StringOfLinesToArray
            //  returns, the constructor call is nested in StringOfLinesToArray,
            //  which splits the lines of text, with their DOS line termiators,
            //  into the required array of strings.
            //
            //  Ideally, the blank line should be removed. However, since the
            //  RemoveEmptyEntries member of the StringSplitOptions enumeration
            //  does it for me, I may as well use it, and save myself the future
            //  agrravation, when I will have probably why it happens.
            //  ----------------------------------------------------------------

            return WizardWrx.TextBlocks.StringOfLinesToArray (
                new string ( achrWholeFile ) ,
                StringSplitOptions.RemoveEmptyEntries );
        }   // private static string [ ] LoadTextFileFromAnyAssembly



        /// <summary>
        /// Return TRUE if the FOR loop driven by pintLoopIndex has one or more
        /// iteration to go, given that the limit criterion is pintLoopIndex is less
        /// than to pintLimit.
        /// </summary>
        /// <param name="pintLimit">
        /// Specify the integer limit value.
        /// </param>
        /// <returns>
        /// This function returns TRUE if the index and limit indicate that one
        /// or more iterations remain.
        /// </returns>
        /// <remarks>
        /// Sometimes, it is more sensible to test whether there are iterations
        /// remaining.
        /// </remarks>
        /// <seealso cref="IsLastForIterationLE"/>
        public static bool MoreForIterationsToComeLE ( 
            int pintLoopIndex , 
            int pintLimit )
        {
            return pintLoopIndex + NEXT_INDEX < pintLimit;
        }   // public static bool MoreForIterationsToComeLE


        /// <summary>
        /// Given an index, such as an array subscript, return the equivalent
        /// ordinal value.
        /// </summary>
        /// <param name="pintIndex">
        /// Specify the index to convert.
        /// </param>
        /// <returns>
        /// The return value is the ordinal equivalent to pintIndex.
        /// </returns>
        /// <remarks>
        /// Mathematically, the ordinal is pintIndex + ORDINAL_FROM_INDEX.
        /// Hence, this routine is syntactic sugar, which a good optimizer will
        /// optimize away by inlining.
        /// </remarks>
        public static int OrdinalFromIndex ( int pintIndex )
        {
            return pintIndex + ORDINAL_FROM_INDEX;
        }   // public static int OrdinalFromIndex
        #endregion  // Public Static Methods


        #region Private Static Methods
        /// <summary>
        /// Use the list of Manifest Resource Names returned by method
        /// GetManifestResourceNames on a specified assembly. Each of several
        /// methods employs a different mechanism to identify the assembly of
        /// interest.
        /// </summary>
        /// <param name="pstrResourceName">
        /// Specify the name of the file from which the embedded resource was
        /// created. Typically, this will be the local name of the file in the
        /// source code tree.
        /// </param>
        /// <param name="pasmSource">
        /// Pass a reference to the Assembly that is supposed to contain the
        /// desired resource.
        /// </param>
        /// <returns>
        /// If the function succeeds, the return value is the internal name of
        /// the requested resource, which is fed to GetManifestResourceStream on
        /// the same assembly, which returns a read-only Stream backed by the
        /// embedded resource. If the specified resource is not found, it
        /// returns null (Nothing in Visual Basic).
        /// </returns>
        private static string GetInternalResourceName (
            string pstrResourceName , 
            Assembly pasmSource )
        {
            foreach ( string strManifestResourceName in pasmSource.GetManifestResourceNames ( ) )
                if ( strManifestResourceName.EndsWith ( pstrResourceName ) )
                    return strManifestResourceName;

            return null;
        }   // private static string GetInternalResourceName
        #endregion  //  Private Static Methods
    }   // public sealed class Util
}   // partial namespace TimeZoneLab