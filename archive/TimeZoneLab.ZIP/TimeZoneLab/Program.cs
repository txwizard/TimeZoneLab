﻿/*
    ============================================================================

    Module Name:        Program.cs

    Namespace Name:     TimeZoneLab

    Class Name:         Program

    Synopsis:           This command line appliction is a test platform for
                        experimenting with times and time zones.

    Remarks:            This class module implements the Program class, which is
                        composed exclusively of the static void Main method,
                        which is functionally equivalent to the main() routine
                        of a standard C program.

    Author:             David A. Gray

    Created:            Saturday, 30 August 2014 - Tuesday 02 September 2014

    ----------------------------------------------------------------------------
    Revision History
    ----------------------------------------------------------------------------

    Date       Version Author Synopsis
    ---------- ------- ------ -------------------------------------------------
    2014/09/02 1.0     DAG    This is the first version.
    2014/09/04 1.1     DAG/WW Clean up documentation and formatting of output to
                              make the project suitable for publication.
    ============================================================================
*/


using System;
using System.Collections.Generic;
using System.Text;

/*  Added by DAG */

using WizardWrx;
using WizardWrx.ApplicationHelpers2;
using WizardWrx.ConsoleAppAids2;
using WizardWrx.DLLServices2;

namespace TimeZoneLab
{
    class Program
    {
        enum OutputFormat
        {
            Verbose = 0 ,                                                       // Tell all
            Terse = 1 ,                                                         // Just the facts
            None = 2 ,                                                          // Silence!
            Quiet = 2 ,                                                         // Equivalent to None
            V = 0 ,                                                             // Equivalent to Verbose
            T = 1 ,                                                             // Equivalent to Terse
            N = 2 ,                                                             // Equivalent to None
            Q = 2                                                               // Equivalent to None
        };  // enum OutputFormat

        enum Task
        {
            All ,
            AnyTimeZoneToAnyOtherTimeZone ,                                     // ConvertBetweenAnyTwoTimeZones
            EnumTimeZones ,                                                     // EnumerateTimeZones
            AnyTimeZoneToUTC ,                                                  // ConvertAnyTimeZoneToUTC
            AnyTimeZoneToLocalTime ,                                            // ConvertAnyTimeZoneToLocalTime
        }   // enum Task

        public const int ARRAY_BEGIN = StandardConstants.ARRAY_FIRST_ELEMENT;
        public const string EMPTY_STRING = StandardConstants.EMPTY_STRING;
        public const int ERR_SUCCEEDED = StandardConstants.ERROR_SUCCESS;
        public const char HYPHEN = StandardConstants.HYPHEN;
        public const char QUOTE = StandardConstants.QUOTE_CHAR;
        public const char TAB = StandardConstants.TAB_CHAR;

        const int ERR_RUNTIME = 1;
        const int ERR_TASK_SPECIFIER_INVALID = 2;
        const int ERR_UNIMPLEMENTED_TASK = 3;

        public const int ERR_TEST_CASE_FILENAME_IS_MISSING = 4;
        public const int ERR_TEST_CASE_FILE_NOT_FOUND = 5;

        static string [ ] s_astrErrorMessages =
        {
            Properties.Resources.ERRMSG_SUCCESS ,                               // ERROR_SUCCESS
            Properties.Resources.ERRMSG_RUNTIME ,                               // ERR_RUNTIME
            Properties.Resources.ERRMSG_TASK_SPECIFIER_INVALID ,                // ERR_TASK_SPECIFIER_INVALID
            Properties.Resources.ERRMSG_UNIMPLEMENTED_TASK ,                    // ERR_UNIMPLEMENTED_TASK
            Properties.Resources.ERRMSG_TEST_CASE_FILENAME_IS_MISSING ,         // ERR_TEST_CASE_FILENAME_IS_MISSING
            Properties.Resources.ERRMSG_TEST_CASE_FILE_NOT_FOUND ,              // ERR_TEST_CASE_FILE_NOT_FOUND
        };  // static string [ ] s_astrErrorMessages

        static ConsoleAppStateManager s_theApp;

        //  --------------------------------------------------------------------
        //  This argument specifies one of three supported formats for the 
        //  STDOUT display.
        //  --------------------------------------------------------------------

        const char SW_OUTPUT = 'o';

        static char [ ] s_achrValidSwitches =
        {
            SW_OUTPUT ,
        };  // static char [ ] s_achrValidSwitches

        static void Main ( string [ ] args )
        {
            CmdLneArgsBasic cmdArgs = new CmdLneArgsBasic (
                s_achrValidSwitches ,
                CmdLneArgsBasic.ArgMatching.CaseInsensitive );
            cmdArgs.AllowEmptyStringAsDefault = CmdLneArgsBasic.BLANK_AS_DEFAULT_ALLOWED;

            s_theApp = ConsoleAppStateManager.GetTheSingleInstance ( );

            //  ----------------------------------------------------------------
            //  The default value of the AppSubsystem property is GUI, which
            //  disables output to the console. Since ReportException returns
            //  the message that would have been written, you still have the
            //  option of displaying or discarding it. If EventLoggingState is
            //  set to Enabled, the message is written into the Application
            //  Event log, where it is preserved until the event log record is
            //  purged by the aging rules or some other method.
            //  ----------------------------------------------------------------

            s_theApp.BaseStateManager.AppExceptionLogger.OptionFlags =
                s_theApp.BaseStateManager.AppExceptionLogger.OptionFlags
                | ExceptionLogger.OutputOptions.EventLog
                | ExceptionLogger.OutputOptions.Stack
                | ExceptionLogger.OutputOptions.StandardError;
            s_theApp.BaseStateManager.LoadErrorMessageTable ( s_astrErrorMessages );

            string strDeferredMessage = null;

            OutputFormat enmOutputFormat = SetOutputFormat (
                cmdArgs ,
                ref strDeferredMessage );

            if ( enmOutputFormat != OutputFormat.None )
            {   // Unless output is suppressed, display the standard BOJ message.
                s_theApp.DisplayBOJMessage ( );
            }   // if ( enmOutputFormat != OutputFormat.None )

            if ( !string.IsNullOrEmpty ( strDeferredMessage ) )
            {   // SetOutputFormat saves its error message, if any, in SetOutputFormat. 
                Console.WriteLine ( strDeferredMessage );
            }   // if ( !string.IsNullOrEmpty ( s_strDeferredMessage ) )

            string [ ] astrTaskOutputLabels = Util.LoadTextFileFromEntryAssembly ( Properties.Resources.TASK_LABEL_FILENAME );
            Task enmAssignedTask = IdentifyTeaskToRun ( cmdArgs );

            Console.WriteLine (
                Properties.Resources.MSG_SELECTED_TASK ,
                enmAssignedTask ,
                Environment.NewLine );

            try
            {
                switch ( enmAssignedTask )
                {
                    case Task.EnumTimeZones:
                        s_theApp.BaseStateManager.AppReturnCode = TimeZoneTasks.EnumerateTimeZones ( astrTaskOutputLabels [ ( int ) Task.EnumTimeZones ] );
                        break;
                    case  Task.AnyTimeZoneToAnyOtherTimeZone:
                        s_theApp.BaseStateManager.AppReturnCode = TimeZoneTasks.ConvertBetweenAnyTwoTimeZones ( astrTaskOutputLabels [ ( int ) Task.AnyTimeZoneToAnyOtherTimeZone ] );
                        break;
                    case Task.AnyTimeZoneToUTC:
                        s_theApp.BaseStateManager.AppReturnCode = TimeZoneTasks.ConvertAnyTimeZoneToUTC ( astrTaskOutputLabels [ ( int ) Task.AnyTimeZoneToUTC ] );
                        break;
                    case Task.AnyTimeZoneToLocalTime:
                        s_theApp.BaseStateManager.AppReturnCode = TimeZoneTasks.ConvertAnyTimeZoneToLocalTime ( astrTaskOutputLabels [ ( int ) Task.AnyTimeZoneToLocalTime ] );
                        break;
                    case Task.All:
                        s_theApp.BaseStateManager.AppReturnCode = TimeZoneTasks.EnumerateTimeZones ( astrTaskOutputLabels [ ( int ) Task.EnumTimeZones ] );
                        s_theApp.BaseStateManager.AppReturnCode = TimeZoneTasks.ConvertBetweenAnyTwoTimeZones ( astrTaskOutputLabels [ ( int ) Task.AnyTimeZoneToAnyOtherTimeZone ] );
                        s_theApp.BaseStateManager.AppReturnCode = TimeZoneTasks.ConvertAnyTimeZoneToUTC ( astrTaskOutputLabels [ ( int ) Task.AnyTimeZoneToUTC ] );
                        s_theApp.BaseStateManager.AppReturnCode = TimeZoneTasks.ConvertAnyTimeZoneToLocalTime ( astrTaskOutputLabels [ ( int ) Task.AnyTimeZoneToLocalTime ] );
                        break;
                    default:
                        s_theApp.ErrorExit ( ERR_UNIMPLEMENTED_TASK );
                        break;
                }   // switch ( enmAssignedTask )

                if ( s_theApp.BaseStateManager.AppReturnCode > ERR_SUCCEEDED )
                {   // Since s_theApp.BaseStateManager.AppReturnCode is cast to int, as is the framework exit code, it must be cast to uint for s_theApp.ErrorExit.
                    s_theApp.ErrorExit ( (uint) s_theApp.BaseStateManager.AppReturnCode );
                }   // if ( s_theApp.BaseStateManager.AppReturnCode != ERR_SUCCEEDED )
            }
            catch ( Exception exAll )
            {   // The Message string is displayed, but the complete exception goes to the event log.
                s_theApp.BaseStateManager.AppExceptionLogger.ReportException (
                    exAll ,
                    Properties.Resources.METHOD_NAME_IS_MAIN );

                switch ( s_theApp.BaseStateManager.AppExceptionLogger.OptionFlags )
                {   // If StandardError or StandardOutput is ON, the message already printed.
                    case ExceptionLogger.OutputOptions.StandardError:
                    case ExceptionLogger.OutputOptions.StandardOutput:
                        break;
                    default:
                        Console.WriteLine ( exAll.Message );
                        break;
                }   // switch ( s_theApp.BaseStateManager.AppExceptionLogger.OptionFlags )

                ExitWithError (
                    enmOutputFormat ,
                    ERR_RUNTIME );
            }   // Providing a catch block is enough to cause the program to fall through.

            Console.WriteLine (
                Properties.Resources.MSG_TASK_DONE ,
                enmAssignedTask ,
                Environment.NewLine );

#if DEBUG
            if ( enmOutputFormat == OutputFormat.None )
            {   // Suppress all output.
                s_theApp.NormalExit ( ConsoleAppStateManager.NormalExitAction.Silent );
            }   // TRUE block, if ( enmOutputFormat == OutputFormat.None )
            else
            {   // Display the standard exit banner.
                if ( System.Diagnostics.Debugger.IsAttached )
                    s_theApp.NormalExit ( ConsoleAppStateManager.NormalExitAction.WaitForOperator );
                else
                    s_theApp.NormalExit ( ConsoleAppStateManager.NormalExitAction.Timed );
            }   // FALSE block, if ( enmOutputFormat == OutputFormat.None )
#else
            if ( enmOutputFormat == OutputFormat.None )
            {   // Suppress all output.
                s_theApp.NormalExit ( ConsoleAppStateManager.NormalExitAction.Silent );
            }   // TRUE block, if ( enmOutputFormat == OutputFormat.None )
            else
            {   // Display the standard exit banner.
                s_theApp.NormalExit ( ConsoleAppStateManager.NormalExitAction.ExitImmediately );
            }   // FALSE block, if ( enmOutputFormat == OutputFormat.None )
#endif
        }   // static void Main

        private static Task IdentifyTeaskToRun ( CmdLneArgsBasic cmdArgs )
        {
            const int ARGBYPOS_TASK = CmdLneArgsBasic.FIRST_POSITIONAL_ARG;
            const string ARG_OMITTED = EMPTY_STRING;
            const bool ARG_PARSE_IGNORE_CASE = true;

            const string ERRMSG_INVALID_TASK_ID = @"The specified task, {0}, is invalid.";

            //  ----------------------------------------------------------------
            //  Since the string appears in error messages, it's cheaper to 
            //  stash a copy here.
            //  ----------------------------------------------------------------

            string strTaskArg = cmdArgs.GetArgByPosition (
                ARGBYPOS_TASK ,
                ARG_OMITTED );

            //  ------------------------------------------------------------
            //  The catch blocks that follow end with a return that is
            //  unreachable. The compiler doesn't know that, because it
            //  cannot possibly know that ErrorExit shuts down the program.
            //
            //  Since the method signature tells the compiler to expect this
            //  method to return a Task, it complains loudly, to the effect
            //  that not all paths return a value, which the C# compiler 
            //  treats as a fatal compilation error. In contrast, the Visual
            //  C++ compiler treats this condition as a warning.
            //  ------------------------------------------------------------

            if ( string.IsNullOrEmpty ( strTaskArg ) )
            {   // The terse message generated by ErrorExit is plenty.
                return Task.All;
            }   // if ( string.IsNullOrEmpty ( strTaskArg ) )

            try
            {
                return ( Task ) Enum.Parse (
                    typeof ( Task ) ,
                    strTaskArg ,
                    ARG_PARSE_IGNORE_CASE );
            }   // We're done. The remaining code is composed of catch blocks.
            catch ( ArgumentNullException errArgIsNull )
            {
                s_theApp.BaseStateManager.AppExceptionLogger.ReportException (
                    errArgIsNull ,
                    Properties.Resources.METHOD_NAME_IS_MAIN );
                s_theApp.ErrorExit ( ERR_RUNTIME );
                return Task.EnumTimeZones;
            }   // catch ( ArgumentNullException errArgIsNull )
            catch ( ArgumentException errArgIsInvalid )
            {
                if ( typeof ( Task ) == typeof ( Enum ) )
                {   // It isn't worth the work to evaluate the white space case.
                    Console.WriteLine (
                        ERRMSG_INVALID_TASK_ID ,
                        strTaskArg );
                    s_theApp.ErrorExit ( ERR_TASK_SPECIFIER_INVALID );
                    return Task.EnumTimeZones;
                }   // TRUE (expected outcome) block, if ( typeof ( Task ) == typeof ( Enum ) )
                else
                {   // The enumType, typeof ( Task ), is not an Enum.
                    s_theApp.BaseStateManager.AppExceptionLogger.ReportException (
                        errArgIsInvalid ,
                        Properties.Resources.METHOD_NAME_IS_MAIN );
                    s_theApp.ErrorExit ( ERR_RUNTIME );
                    return Task.EnumTimeZones;
                }   // FALSE (UNexpected outcome) block, if ( typeof ( Task ) == typeof ( Enum ) )
            }   // catch ( ArgumentException errArgIsInvalid )
            catch ( OverflowException errOverflow )
            {
                s_theApp.BaseStateManager.AppExceptionLogger.ReportException (
                    errOverflow ,
                    Properties.Resources.METHOD_NAME_IS_MAIN );
                s_theApp.ErrorExit ( ERR_RUNTIME );
                return Task.EnumTimeZones;
            }   // catch ( OverflowException errOverflow )
            catch ( Exception errMisc )
            {   // Some totally unexpected error happened.
                s_theApp.BaseStateManager.AppExceptionLogger.ReportException (
                    errMisc ,
                    Properties.Resources.METHOD_NAME_IS_MAIN );
                s_theApp.ErrorExit ( ERR_RUNTIME );
                return Task.EnumTimeZones;
            }   // catch ( Exception errMisc )
        }   // private static Task IdentifyTeaskToRun


        private static void ExitWithError (
            OutputFormat penmOutputFormat ,
            uint puintStatusCode )
        {
            if ( penmOutputFormat == OutputFormat.Quiet )
                s_theApp.NormalExit (
                    puintStatusCode ,
                    ConsoleAppStateManager.NormalExitAction.Silent );
            else
                if ( System.Diagnostics.Debugger.IsAttached)
                    s_theApp.NormalExit (
                        puintStatusCode ,
                        ConsoleAppStateManager.NormalExitAction.WaitForOperator );
                else
                    s_theApp.NormalExit (
                        puintStatusCode ,
                        ConsoleAppStateManager.NormalExitAction.ExitImmediately );
        }   // private static void ExitWithError


        private static OutputFormat SetOutputFormat (
            CmdLneArgsBasic pcmdArgs ,
            ref string pstrDeferredMessage )
        {
            //  ----------------------------------------------------------------
            //  An invalid input value elicits a message similar to the following.
            //
            //      Requested value 'Foolish' was not found.
            //
            //  The simplest way to report an invalid value is by extrqacting it
            //  from the Message property of the ArgumentException thrown by the
            //  Enum.Parse method.
            //
            //  I happen to have a library routine, ExtractBoundedSubstrings,
            //  which became part of a sealed class, WizardWrx.StringTricks,
            //  exported by class library WizardWrx.SharedUtl2.dll version 2.62,
            //  which came into being exactly two years ago, 2011/11/23.
            //  ----------------------------------------------------------------

            const bool IGNORE_CASE = true;
            const int NONE = 0;

            OutputFormat renmOutputFormat = OutputFormat.Verbose;

            //  ----------------------------------------------------------------
            //  Enum.Parse needs a try/catch block, becauce an invalid SW_OUTPUT
            //  value raises an exception that can be gracefully handled without
            //  killing the program.
            //  ----------------------------------------------------------------

            try
            {
                if ( pcmdArgs.ValidSwitchesInCmdLine > NONE )
                {
                    renmOutputFormat = ( OutputFormat ) Enum.Parse (
                        typeof ( OutputFormat ) ,
                        pcmdArgs.GetSwitchByName (
                            SW_OUTPUT ,
                            OutputFormat.Verbose.ToString ( ) ) ,
                        IGNORE_CASE );
                }   // if ( pcmdArgs.ValidSwitchesInCmdLine > NONE )
            }
            catch ( ArgumentException exArg )
            {   // Display of the message is deferred until the BOJ message is printed.
                s_theApp.BaseStateManager.AppExceptionLogger.ReportException (
                    exArg ,
                    System.Reflection.MethodBase.GetCurrentMethod ( ).Name );
                pstrDeferredMessage = string.Format (
                    Properties.Resources.ERRMSG_INVALID_OUTPUT_FORMAT ,
                    WizardWrx.StringTricks.ExtractBoundedSubstrings (
                        exArg.Message ,
                        WizardWrx.StandardConstants.SINGLE_QUOTE ) ,
                    renmOutputFormat ,
                    Environment.NewLine );
            }

            return renmOutputFormat;
        }   // private static OutputFormat SetOutputFormat
    }   // class Program
}   // partial namespace TimeZoneLab