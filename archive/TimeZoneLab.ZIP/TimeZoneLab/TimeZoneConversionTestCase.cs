﻿/*
    ============================================================================

    Namespace:          TimeZoneLab

    Class Name:         TimeZoneConversionTestCase

    File Name:          TimeZoneConversionTestCase.cs

    Synopsis:           This class exposes a test case, and provides spaces to
                        record the answers, so that the the complete set can be
                        formatted into a fixed length ASCII report like the one
                        that I made of the time zone enumeration.

    Remarks:            Sentence

    Author:             David A. Gray, Simple Soft Services, Inc.

    Copyright:          Copyright 2014, Simple Soft Services, Inc.

    Created:            Sunday, 31 August 2014 - Tuesday, 01 September 2014

    ----------------------------------------------------------------------------
    Revision History
    ----------------------------------------------------------------------------

    Date       Version Author Description
    ---------- ------- ------ --------------------------------------------------
    2014/09/02 1.0     DAG/WW Initial implementation.
    ============================================================================
*/


using System;
using System.Collections.Generic;
using System.Text;

namespace TimeZoneLab
{
    class TimeZoneConversionTestCase : IComparable
    {
        #region Instance Storage
        uint _uintCaseNumber;
        DateTime _dtmTestDate = DateTime.MinValue;
        string _strTestDateTimeZoneID = null;
        string _strComment = null;
        DateTime _dtmOutputDate = DateTime.MinValue;
        string _strOutputDateTimeZoneID = null;
        #endregion  // Instance Storage


        #region Constructors
        public TimeZoneConversionTestCase ( )
        { } // public TimeZoneConversionTestCase constructor (1 of 2)

        public TimeZoneConversionTestCase (
            uint puintCaseNumber ,
            string pstrTestDate ,
            string pstrComment ,
            string pstrTZIDIn ,
            string pstrTZIdOut)
        {
            const string ARGNAME_COMMENT = @"pstrComment";
            const string ARGNAME_TZ_ID_IN = @"pstrTZIDIn";
            const string ARGNEME_TZ_ID_OUT=@"pstrTZIdOut";
            const string ARGNAME_TEST_DATE = @"pstrTestDate";

            const string ERRMSG_TRYPARSE = @"DateTime.TryParse cannot parse this value.";

            if ( DateTime.TryParse ( pstrTestDate , out _dtmTestDate ) )
            {
                if ( string.IsNullOrEmpty ( pstrComment ) )
                {
                    throw new ArgumentNullException ( ARGNAME_COMMENT );
                }
                else if ( string.IsNullOrEmpty ( pstrTZIDIn ) )
                {
                    throw new ArgumentNullException ( ARGNAME_TZ_ID_IN );
                }
                else if ( string.IsNullOrEmpty ( pstrTZIdOut ) )
                {
                    throw new ArgumentNullException ( ARGNEME_TZ_ID_OUT );
                }
                else
                {
                    _strComment = pstrComment;
                    _uintCaseNumber = puintCaseNumber;
                    _strTestDateTimeZoneID = pstrTZIDIn;
                    _strOutputDateTimeZoneID = pstrTZIdOut;
                }   // FALSE (desired outcome!) block, if ( string.IsNullOrEmpty ( pstrComment ) ) ...
            }   // TRUE (expected outcome) block, if ( DateTime.TryParse ( pstrTestDate , out _dtmTestDate ) )
            else
            {
                throw new ArgumentOutOfRangeException (
                    ARGNAME_TEST_DATE ,
                    pstrTestDate ,
                    ERRMSG_TRYPARSE );
            }   // expected outcome) block, if ( DateTime.TryParse ( pstrTestDate , out _dtmTestDate ) )
        }   // public TimeZoneConversionTestCase constructor (2 of 2)
        #endregion  // Constructors


        #region Properties
        public uint CaseNumber
        {
            get { return _uintCaseNumber; }
        }   // public uint CaseNumber (READ ONLY and immutable)

        public string DisplayCaseNumber
        {
            get { return _uintCaseNumber.ToString ( ); }
        }   // public string DisplayCaseNumber (READ ONLY and immutable)

        public DateTime TestDate
        {
            get { return _dtmTestDate; }
        }   // public DateTime TestDate (READ ONLY and immutable)

        public string TestDateTimeZoneID
        {
            get { return _strTestDateTimeZoneID; }
        }   // public string TestDateTimeZoneID (READ ONLY and immutable)

        public string OutputDateTimeZoneID
        {
            get 
            {
                return _strOutputDateTimeZoneID;
            }
        }   // public string OutputDateTimeZoneID (READ ONLY and immutable)

        public string Comment
        {
            get { return _strComment; }
        }   // public string Comment (READ ONLY and immutable)

        public string DisplayTestDate
        {
            get
            {
                return Util.FormatDateForShow ( _dtmTestDate );
            }   // public string DisplayTestDate getter
        }   // public string DisplayTestDate (READ ONLY)

        public string DisplayTestDateTimeZone
        {
            get
            {
                return Util.GetDisplayTimeZone (
                    _dtmTestDate ,
                    _strTestDateTimeZoneID );
            }   // // public string DisplayTestDateTimeZone getter
        }   // public string DisplayTestDateTimeZone (READ ONLY)

        public DateTime OutputDate
        {
            get { return _dtmOutputDate; }
            set { _dtmOutputDate = value; }
        }   // public DateTime OutputDate (Read/Write)

        public string DisplayOutputDate
        {
            get
            {
                return Util.FormatDateForShow ( _dtmOutputDate );
            }   // public string DisplayOutputDate getter
        }   // public string DisplayOutputDate (READ ONLY)

        public string DisplayOutputDateTimeZone
        {
            get
            {
                return Util.GetDisplayTimeZone (
                    _dtmOutputDate ,
                    _strOutputDateTimeZoneID );
            }   // // public string DisplayOutputDateTimeZone getter
        }   // public string DisplayOutputDateTimeZone (READ ONLY)


        public string [ ] ColumnValues
        {
            get
            {
                return new string [ ]
                {
                    DisplayCaseNumber ,
                    Comment ,
                    DisplayTestDate ,
                    DisplayTestDateTimeZone ,
                    DisplayOutputDate ,
                    DisplayOutputDateTimeZone
                };
            }   // public string [ ] ColumnValues getter
        }   // public string [ ] ColumnValues (READ ONLY)
        #endregion  // Properties


        #region IComparable Members
        public int CompareTo ( object obj )
        {
            const string ERRMSG_INCOPMARABLE = @"CompareTo method requires {0} type. Specified comparand is of {1} type.";

            Type typeOfThis = this.GetType ( );
            Type typeOfOther = obj.GetType ( );

            if ( obj.GetType ( ) == this.GetType ( ) )
            {
                TimeZoneConversionTestCase tc = ( TimeZoneConversionTestCase ) obj;
                return this._uintCaseNumber.CompareTo ( tc );
            }   // TRUE (expected outcome) block, if ( obj.GetType ( ) == this.GetType ( ) )
            else
            {
                string strMsg=string.Format(ERRMSG_INCOPMARABLE,typeOfThis,typeOfOther);
                throw new InvalidCastException ( strMsg );
            }   // FALSE (UNexpected outcome) block, if ( obj.GetType ( ) == this.GetType ( ) )
        }   // public int CompareTo
        #endregion
    }   // class TimeZoneConversionTestCase
}   // partial namespace TimeZoneLab