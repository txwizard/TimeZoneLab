﻿/*
    ============================================================================

    Namespace:          TimeZoneLab

    Class Name:         TimeZoneTasks

    File Name:          TimeZoneTasks.cs

    Synopsis:           This class exposes static methods for experimenting with
                        time zones.

    Remarks:            I segregated these routines to keep the globalization
                        namespaces out of the main program, and to simplify
                        finding and extracting code for use in production work.

    Author:             David A. Gray, Simple Soft Services, Inc.

    Copyright:          Copyright 2014, Simple Soft Services, Inc.

    Created:            Saturday, 30 August 2014 - Tuesday 02 September 2014

    ----------------------------------------------------------------------------
    Revision History
    ----------------------------------------------------------------------------

    Date       Version Author Synopsis
    ---------- ------- ------ -------------------------------------------------
    2014/09/02 1.0     DAG    This is the first version.
    2014/09/04 1.1     DAG/WW Clean up documentation and formatting of output to
                              make the project suitable for publication.
    ============================================================================
*/


using System;
using System.Collections.ObjectModel;



namespace TimeZoneLab
{
    static class TimeZoneTasks
    {
        const string TEST_FROM_TIMEZONE_ID = TimeZoneConversionTestCaseCollection.TZ_ID_MOUNTAIN;

        //  ----------------------------------------------------------------------------
        //  The first case is a date that captured from the FTP server. The other dates
        //  test edge cases around the 2014 transition dates.
        //
        //  During 2014, Daylight Saving Time is in effect from March 9 at 2 a.m. 
        //  (local time) to November 2 at 2 a.m. (local time).
        //
        //  Reference:  "Information about the Current Daylight Saving Time (DST) Rules"
        //              http://www.nist.gov/pml/div688/dst.cfm
        //  ----------------------------------------------------------------------------

        enum ReportField
        {
            Id ,
            DisplayName ,
            BaseUTCoffset ,
            StandardName, 
            DaylightName ,
            SupportsDST 
        }   // enum ReportField

        static TimeZoneInfo s_tzTestValue = TimeZoneInfo.FindSystemTimeZoneById ( TEST_FROM_TIMEZONE_ID );


        internal static int ConvertAnyTimeZoneToUTC ( string pstrOutputLabel )
        {   // This could be refactored, but I decided that it wasn't worth the extra complexity.

            //  -------------------------------------------------------------------------------
            //  References: 1)  "Converting Times Between Time Zones"
            //                  Microsoft .NET Framework 3.5
            //                  http://msdn.microsoft.com/en-us/library/bb397769(v=vs.90).aspx
            //
            //              2)  "How to: Access the Predefined UTC and Local Time Zone Objects"
            //                  Microsoft .NET Framework 3.5
            //                  http://msdn.microsoft.com/en-us/library/bb397767(v=vs.90).aspx
            //  -------------------------------------------------------------------------------

            Console.WriteLine (
                Properties.Resources.MSG_OUTPUT_BEGIN ,     // Message template
                pstrOutputLabel ,                           // Format Item 0
                Environment.NewLine );                      // Format Item 1

            DateTime [ ] adtmTestDates;
            int rintStatus = GetTestCaseDates ( out adtmTestDates );

            if ( rintStatus > Program.ERR_SUCCEEDED )
                return rintStatus;

            int intCaseNumber = Util.FIRST_ITEM;
            
            foreach ( DateTime dtmFrom in adtmTestDates )
            {
                intCaseNumber++;
                DateTime dtmTo = TimeZoneInfo.ConvertTimeToUtc (
                    dtmFrom ,
                    s_tzTestValue );
                Console.WriteLine (
                    Properties.Resources.MSG_TZ_CONVERSION ,                    // Format Template
                    new string [ ]
                    {
                        intCaseNumber.ToString ( ) ,                            // Format Item 0
                        Util.FormatDateForShow ( dtmFrom ) ,                    // Format Item 1
                        Util.GetDisplayTimeZone (                               // Format Item 2
                            dtmFrom ,                                               // DateTime pdtmTestDate
                            TEST_FROM_TIMEZONE_ID ) ,                               // string pstrTimeZoneID
                        Util.FormatDateForShow ( dtmTo ) ,                      // Format Item 3
                        Util.GetDisplayTimeZone (                               // Format Item 4
                            dtmTo ,                                                 // DateTime pdtmTestDate
                            Util.UTC_TIMEZONE_ID ) ,                                // string pstrTimeZoneID
                        Environment.NewLine                                     // Format Item 5
                    } );
            }   // foreach ( DateTime dtmFrom in adtmTestDates )

            Console.WriteLine (
                Properties.Resources.MSG_OUTPUT_DONE ,      // Message template
                pstrOutputLabel ,                           // Format Item 0
                Environment.NewLine );                      // Format Item 1
            return Program.ERR_SUCCEEDED;
        }   // internal static int ConvertAnyTimeZoneToUTC


        internal static int ConvertAnyTimeZoneToLocalTime ( string pstrOutputLabel )
        {   // This could be refactored, but I decided that it wasn't worth the extra complexity.
            
            Console.WriteLine (
                Properties.Resources.MSG_OUTPUT_BEGIN ,     // Message template
                pstrOutputLabel ,                           // Format Item 0
                Environment.NewLine );                      // Format Item 1

            DateTime [ ] adtmTestDates;
            int rintStatus = GetTestCaseDates ( out adtmTestDates );

            if ( rintStatus > Program.ERR_SUCCEEDED )
                return rintStatus;

            int intCaseNumber = Util.FIRST_ITEM;

            foreach ( DateTime dtmFrom in adtmTestDates )
            {
                intCaseNumber++;
                DateTime dtmTo = TimeZoneInfo.ConvertTime (
                    dtmFrom ,                                                   // DateTime dateTime
                    s_tzTestValue ,                                             // TimeZoneInfo sourceTimeZone
                    TimeZoneInfo.Local );                                       // TimeZoneInfo destinationTimeZone
                Console.WriteLine (
                    Properties.Resources.MSG_TZ_CONVERSION ,                    // Format Template
                    new string [ ]
                    {
                        intCaseNumber.ToString ( ) ,                            // Format Item 0
                        Util.FormatDateForShow ( dtmFrom ) ,                    // Format Item 1
                        Util.GetDisplayTimeZone (                               // Format Item 2
                            dtmFrom ,                                               // DateTime pdtmTestDate
                            TEST_FROM_TIMEZONE_ID ) ,                               // string pstrTimeZoneID
                        Util.FormatDateForShow ( dtmTo ) ,                      // Format Item 3
                        Util.GetDisplayTimeZone (                               // Format Item 4
                            dtmTo ,                                                 // DateTime pdtmTestDate
                            TimeZoneInfo.Local.Id ) ,                               // string pstrTimeZoneID
                        Environment.NewLine                                     // Format Item 5
                    } );
            }   // foreach ( DateTime dtmFrom in adtmTestDates )

            Console.WriteLine (
                Properties.Resources.MSG_OUTPUT_DONE ,      // Message template
                pstrOutputLabel ,                           // Format Item 0
                Environment.NewLine );                      // Format Item 1
            return Program.ERR_SUCCEEDED;
        }   // internal static int ConvertAnyTimeZoneToLocalTime


        internal static int ConvertBetweenAnyTwoTimeZones ( string pstrOutputLabel )
        {
            //  ---------------------------------------------------------------------------------------------
            //  References: 1)  "Converting Times Between Time Zones"
            //                  .NET Framework 3.5
            //                  http://msdn.microsoft.com/en-us/library/bb397769(v=vs.90).aspx
            //
            //              2) "TimeZoneInfo.ConvertTimeBySystemTimeZoneId Method (DateTime, String, String)"
            //                  .NET Framework 3.5
            //                  http://msdn.microsoft.com/en-us/library/bb382058(v=vs.90).aspx
            //  ---------------------------------------------------------------------------------------------

            const string ERRMSG_TEST_FAIL = @"{1}ERROR: Raw Test Date = {0} - Item SKIPPED.{1}";

            Console.WriteLine (
                Properties.Resources.MSG_OUTPUT_BEGIN ,     // Message template
                pstrOutputLabel ,                           // Format Item 0
                Environment.NewLine );                      // Format Item 1
            
            TimeZoneConversionTestCaseCollection tzcColl = new TimeZoneConversionTestCaseCollection ( );

            foreach ( TimeZoneConversionTestCase tc in tzcColl)
            {
                try
                {
                    tc.OutputDate = TimeZoneInfo.ConvertTime (
                        tc.TestDate ,                                           // DateTime dateTime
                        tzcColl.TZTestValue ,                                   // TimeZoneInfo sourceTimeZone
                        tzcColl.TZConverted );                                  // TimeZoneInfo destinationTimeZone
                    Console.WriteLine (
                        Properties.Resources.MSG_TZ_CONVERSION ,                // Format Template
                        new string [ ]
                    {
                        tc.DisplayCaseNumber ,                                  // Format Item 0
                        tc.DisplayTestDate ,                                    // Format Item 1
                        tc.DisplayTestDateTimeZone ,                            // Format Item 2
                        tc.DisplayOutputDate ,                                  // Format Item 3
                        tc.DisplayOutputDateTimeZone ,                          // Format Item 4
                        Environment.NewLine                                     // Format Item 5
                    } );
                }
                catch ( Exception exAll )
                {
                    WizardWrx.ConsoleAppAids2.ConsoleAppStateManager casm = WizardWrx.ConsoleAppAids2.ConsoleAppStateManager.GetTheSingleInstance ( );
                    casm.BaseStateManager.AppExceptionLogger.ReportException (
                        exAll ,
                        System.Reflection.MethodBase.GetCurrentMethod ( ).Name );
                    Console.WriteLine (
                        ERRMSG_TEST_FAIL ,                          // Format template
                        tc.DisplayTestDate ,                        // Format Item 0
                        Environment.NewLine );                      // Format Item 0
                }
            }   // foreach ( TimeZoneConversionTestCase tc in tzcColl)

            tzcColl.CreateReport ( );
            Console.WriteLine (
                Properties.Resources.MSG_OUTPUT_DONE ,      // Message template
                pstrOutputLabel ,                           // Format Item 0
                Environment.NewLine );                      // Format Item 1
            return Program.ERR_SUCCEEDED;
        }   // internal static int ConvertBetweenAnyTwoTimeZones


        internal static int EnumerateTimeZones ( string pstrOutputLabel )
        {
            //  --------------------------------------------------------------------------
            //  Reference:  "How to: Enumerate Time Zones Present on a Computer"
            //              .NET Framework 3.5
            //              http://msdn.microsoft.com/en-us/library/bb397781(v=vs.90).aspx
            //  --------------------------------------------------------------------------

            const string REPORT_TEMPLATE = @"    {0} {1} {2} {3} {4} {5}";
            const string RPT_LBL_ID = @"Id";
            const string RPT_LBL_DN = @"DisplayName";
            const string RPT_LBL_UO = @"BaseUTCoffset";
            const string RPT_LBL_SN = @"StandardName";
            const string RPT_LBL_DT = @"DaylightName";
            const string RPT_LBL_SD = @"SupportsDST";

            Console.WriteLine (
                Properties.Resources.MSG_OUTPUT_BEGIN ,     // Message template
                pstrOutputLabel ,                           // Format Item 0
                Environment.NewLine );                      // Format Item 1

            ReadOnlyCollection<TimeZoneInfo> tzCollection;
            tzCollection = TimeZoneInfo.GetSystemTimeZones ( );

            //  ----------------------------------------------------------------
            //  Rather than call the LengthOfLongestString library routine, this
            //  routine uses a custom routine, MaxLength, which follows the same
            //  pattern, adding an enumerator to select the desired field from a
            //  TimeZoneInfo.
            //  ----------------------------------------------------------------

            int intMaxIdLength = MaxLength (
                tzCollection ,
                ReportField.Id ,
                RPT_LBL_ID );
            int intMaxNameLength = MaxLength (
                tzCollection ,
                ReportField.DisplayName ,
                RPT_LBL_DN );
            int intMaxBaseUTCoffsetLength = MaxLength (
                tzCollection ,
                ReportField.BaseUTCoffset ,
                RPT_LBL_UO );
            int intMaxStandardNameLength = MaxLength (
                tzCollection ,
                ReportField.StandardName ,
                RPT_LBL_SN );
            int intMaxDaylightNameLength = MaxLength (
                tzCollection ,
                ReportField.DaylightName ,
                RPT_LBL_DT );
            int intMaxSupportsDSTLength = MaxLength (
                tzCollection ,
                ReportField.SupportsDST ,
                RPT_LBL_SD );

            Console.WriteLine (
                REPORT_TEMPLATE ,
                new string [ ]
                {
                    RPT_LBL_ID.PadRight ( intMaxIdLength ) ,
                    RPT_LBL_DN.PadRight ( intMaxNameLength ) ,
                    RPT_LBL_UO.PadRight ( intMaxBaseUTCoffsetLength ) ,
                    RPT_LBL_SN.PadRight ( intMaxStandardNameLength ) ,
                    RPT_LBL_DT.PadRight ( intMaxDaylightNameLength ) ,
                    RPT_LBL_SD.PadRight ( intMaxSupportsDSTLength )
                } );
            
            //  ----------------------------------------------------------------
            //  Padding the empty string with hyphens generates a string the
            //  length of the longest value, just what is needed to create a
            //  polished report heading.
            //  ----------------------------------------------------------------

            Console.WriteLine (
                REPORT_TEMPLATE ,
                new string [ ]
                {
                    Program.EMPTY_STRING.PadRight (
                        intMaxIdLength ,
                        Program.HYPHEN ) ,
                    Program.EMPTY_STRING.PadRight (
                        intMaxNameLength ,
                        Program.HYPHEN ) ,
                    Program.EMPTY_STRING.PadRight (
                        intMaxBaseUTCoffsetLength ,
                        Program.HYPHEN ) ,
                    Program.EMPTY_STRING.PadRight (
                        intMaxStandardNameLength ,
                        Program.HYPHEN ) ,
                    Program.EMPTY_STRING.PadRight (
                        intMaxDaylightNameLength ,
                        Program.HYPHEN ) ,
                    Program.EMPTY_STRING.PadRight (
                        intMaxSupportsDSTLength ,
                        Program.HYPHEN )
                } );

            foreach ( TimeZoneInfo timeZone in tzCollection )
                Console.WriteLine (
                    REPORT_TEMPLATE ,
                    new string [ ]
                    {
                        timeZone.Id.PadRight ( intMaxIdLength ) ,
                        timeZone.DisplayName.PadRight ( intMaxNameLength ) ,
                        timeZone.BaseUtcOffset.ToString ( ).PadRight ( intMaxBaseUTCoffsetLength ) ,
                        timeZone.StandardName.PadRight ( intMaxStandardNameLength ) ,
                        timeZone.DaylightName.PadRight ( intMaxDaylightNameLength ) ,
                        timeZone.SupportsDaylightSavingTime.ToString ( ).PadRight ( intMaxSupportsDSTLength )
                    } );
            Console.WriteLine (
                Properties.Resources.MSG_OUTPUT_DONE ,      // Message template
                pstrOutputLabel ,                           // Format Item 0
                Environment.NewLine );                      // Format Item 1
            return Program.ERR_SUCCEEDED;
        }   // internal static int EnumerateTimeZones ( )


        private static int GetTestCaseDates ( out DateTime [ ] padtmTestDates )
        {
            string strTestCaseFileName = Properties.Settings.Default.EdgeCaseInputFileName;

            if ( string.IsNullOrEmpty ( strTestCaseFileName ) )
            {   // The settings file is corrupted.
                padtmTestDates = null;                                           // The compiler insists. It doesn't know that the method is about to craok.
                return Program.ERR_TEST_CASE_FILENAME_IS_MISSING;
            }   // TRUE (unexpected outcome) block, if ( string.IsNullOrEmpty ( strTestFileName ) )
            else if ( System.IO.File.Exists ( strTestCaseFileName ) )
            {
                string [ ] astrTestCases = System.IO.File.ReadAllLines ( strTestCaseFileName );
                int intNRecords = astrTestCases.Length;

                if ( intNRecords > TimeZoneConversionTestCaseCollection.MINIMUM_RECORD_COUNT )
                {
                    padtmTestDates = new DateTime [ intNRecords - Util.NEXT_INDEX ];

                    for ( int intThisCase = TimeZoneConversionTestCaseCollection.MINIMUM_RECORD_COUNT ;
                              intThisCase < intNRecords ;
                              intThisCase++ )
                    {
                        string [ ] astrFields = astrTestCases [ intThisCase ].Split ( Program.TAB );

                        int intFieldCount = astrFields.Length;

                        if ( intFieldCount == TimeZoneConversionTestCaseCollection.EXPECTED_FIELD_COUNT )
                        {   // The record split into the expected number of fields.
                            if ( !DateTime.TryParse ( astrFields [ TimeZoneConversionTestCaseCollection.POS_TEST_DATE ] , out padtmTestDates [ intThisCase - Util.ORDINAL_FROM_INDEX ] ) )
                            {   // If the operation succeeded, its work is done, because it updates the array element.
                                string strMsg = string.Format (
                                    Properties.Resources.ERRMSG_INVALID_DATE_STRING ,
                                    astrFields [ TimeZoneConversionTestCaseCollection.POS_TEST_DATE ] ,
                                    intThisCase ,
                                    strTestCaseFileName );
                                throw new Exception ( strMsg );
                            }   // if ( !DateTime.TryParse ( astrFields [ TimeZoneConversionTestCaseCollection.POS_TEST_DATE ] , out adtmTestDates [ intThisCase - Util.ORDINAL_FROM_INDEX ] ) )
                        }   // TRUE (expected outcome) block, if ( intFieldCount == EXPECTED_FIELD_COUNT )
                        else
                        {   // The record is corrupted; it contains either too few fields or too many.
                            string strMsg = string.Format (
                                TimeZoneConversionTestCaseCollection.ERRMSG_BAD_RECORD ,                         // Mesage template
                                new string [ ]
                                {
                                    strTestCaseFileName ,                   // Format Item 0
                                    intThisCase.ToString ( ) ,              // Format Item 1
                                    astrTestCases [ intThisCase ] ,         // Format Item 2
                                    intFieldCount.ToString ( ) ,            // Format Item 3
                                    TimeZoneConversionTestCaseCollection.EXPECTED_FIELD_COUNT.ToString ( ) ,     // Format Item 4
                                    Environment.NewLine                     // Format Item 5
                                } );
                            throw new ApplicationException ( strMsg );
                        }   // FALSE (UNexpected outcome) block, if ( intFieldCount == EXPECTED_FIELD_COUNT )
                    }   // for ( int intThisCase = TimeZoneConversionTestCaseCollection.MINIMUM_RECORD_COUNT ; intThisCase < intNRecords ; intThisCase++ )

                    return Program.ERR_SUCCEEDED;
                }   // TRUE (expected outcome) block, if ( intNRecords > TimeZoneConversionTestCaseCollection.MINIMUM_RECORD_COUNT )
                else
                {
                    string strMsg = string.Format (
                       TimeZoneConversionTestCaseCollection. ERRMSG_BAD_FILE ,
                        strTestCaseFileName ,
                        Environment.NewLine );
                    throw new ApplicationException ( strMsg );
                }   // FALSE (UNexpected outcome) block, if ( intNRecords > TimeZoneConversionTestCaseCollection.MINIMUM_RECORD_COUNT )
            }   // TRUE (expected outcome) block, else if ( System.IO.File.Exists ( strTestFileName ) )
            else
            {   // The file of test cases got moved.
                padtmTestDates = null;                                           // The compiler insists. It doesn't know that the method is about to craok.
                return Program.ERR_TEST_CASE_FILE_NOT_FOUND;
            }   // FALSE (UNexpected outcome) block, else if ( System.IO.File.Exists ( strTestFileName ) )
        }   // private static int GetTestCaseDates


        /// <summary>
        /// Compute the maximum number of characters required to display the
        /// string representation of a field in a TimeZoneInfo.
        /// </summary>
        /// <param name="ptzCollection">
        /// Supply a reference to the ReadOnlyCollection<TimeZoneInfo> to
        /// analyze.
        /// </param>
        /// <param name="penmReportField">
        /// Specify a member of the ReportField enumeration to identify the
        /// field to evaluate.
        /// </param>
        /// <param name="strFieldLabel">
        /// Supply a reference to the string that you intend to use to label the
        /// column, which determines the minimum required width.
        /// </param>
        /// <returns>
        /// The return value is the length of the longest string representation
        /// of the specified field, or the length of strFieldLabel, whichever is
        /// greater.
        /// </returns>
        private static int MaxLength (
            ReadOnlyCollection<TimeZoneInfo> ptzCollection ,
            ReportField penmReportField ,
            string strFieldLabel )
        {
            const string ARGNAME_REPORTFIELD = @"penmReportField";
            const string UNIMPLEMENTED = @"MaxLength computation is not yet implemented for this field.";

            //  ----------------------------------------------------------------
            //  Initizlizing rintMaxLength to the length of strFieldLabel.Length
            //  saves a minute amount of execution time because any value length
            //  shorter than the label skips the update step.
            //  ----------------------------------------------------------------

            int rintMaxLength = strFieldLabel.Length;
            int intNewLength = -1;

            foreach ( TimeZoneInfo tz in ptzCollection )
            {
                switch ( penmReportField )
                {
                    case ReportField.DisplayName:
                        intNewLength = tz.DisplayName.Length;
                        break;  // case ReportField.DisplayName

                    case ReportField.Id:
                        intNewLength = tz.Id.Length;
                        break;

                    case ReportField.BaseUTCoffset:
                        intNewLength = tz.BaseUtcOffset.ToString ( ).Length;
                        break;

                    case ReportField.StandardName:
                        intNewLength = tz.StandardName.Length;
                        break;

                    case ReportField.DaylightName:
                        intNewLength = tz.DaylightName.Length;
                        break;

                    case ReportField.SupportsDST:
                        intNewLength = tz.SupportsDaylightSavingTime.ToString ( ).Length;
                        break;

                    default:
                        throw new ArgumentOutOfRangeException (
                            ARGNAME_REPORTFIELD ,
                            penmReportField ,
                            UNIMPLEMENTED );
                }   // switch ( penmReportField )

                if ( intNewLength > rintMaxLength )
                {
                    rintMaxLength = intNewLength;
                }   // if ( intNewLength > rintMaxLength )
            }   // foreach ( TimeZoneInfo tz in ptzCollection )

            return rintMaxLength;
        }   // private static int MaxLength
    }   // class TimeZoneTasks
}   // partial namespace TimeZoneLab